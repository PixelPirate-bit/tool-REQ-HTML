LuminaScan

LuminaScan is a Python tool created to analyze websites and APIs in a fast and practical way. It allows you to check headers, status codes, cookies, JSON responses, and much more, all directly from the terminal.

Installation
